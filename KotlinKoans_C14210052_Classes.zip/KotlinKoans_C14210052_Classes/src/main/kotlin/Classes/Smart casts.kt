package Classes

import java.lang.IllegalArgumentException

// Contoh pemakaian:
fun main() {
    val expression = Sum(Num(5), Num(10))
    val result = eval(expression)
    println("Hasil evaluasi: $result")
    // Output: Hasil evaluasi 15
}

fun eval(expr: Expr): Int =
    when (expr){
        is Num -> expr.value // Menggunakan smart cast untuk mengakses properti value dari Num
        is Sum -> eval(expr.left) + eval(expr.right) // Menggunakan smart cast untuk mengevaluasi ekspresi Sum
        else -> throw IllegalArgumentException("Unknown expression")
    }

interface Expr // Membuat interface dengan nama Expr

// penggunaan interface Expr
class Num(val value: Int): Expr
class Sum(val left: Expr, val right: Expr) : Expr




