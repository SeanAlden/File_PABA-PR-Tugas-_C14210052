package Classes

fun Int.r(): RationalNumber = RationalNumber(this, 1)
// Ekstensi function untuk tipe data Int
// yang mengubah integer menjadi RationalNumber
// dengan denominator 1

fun Pair<Int, Int>.r(): RationalNumber = RationalNumber(first, second)
// Ekstensi function untuk tipe data Pair<Int, Int>
// yang mengubah pasangan integer menjadi RationalNumber
// dengan numerator dan denominator yang sesuai

data class RationalNumber(val numerator: Int, val denominator: Int)

fun main() {
    val intRational = 5.r()
    println("Integer to Rational: $intRational")
    // Output: Integer to Rational: RationalNumber(numerator=5, denominator=1)

    val pairRational = Pair(3, 2).r()
    println("Pair to Rational: $pairRational")
    // Output: Pair to Rational: RationalNumber(numerator=3, denominator=2)
}