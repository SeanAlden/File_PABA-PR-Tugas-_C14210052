package Classes

fun main() {
    val result = comparePeople()
    println(result)
    // pemanggilan fungsi comparePeople
}
data class Person(val name: String, val age: Int){
    // Mendefinisikan class Person dengan atribut name dan age
    // kedua atribut ini akan diinisialisasi saat membuat objek Person
}

fun getPeople(): List<Person>{
    // Fungsi getPeople() untuk mengembalikan daftar objek Person
    return listOf(
        Person("Alice", 29),
                  Person("Bob", 31)
    )
    // Mengembalikan daftar pada objek Person yang sudah diinisalisasi dengan
    // nama dan usia yang sudah di tulis serta ditentukan
}

fun comparePeople(): Boolean{
    // fungsi comparePeople() untuk membandingkan dua objek Person
    val p1 = Person("Alice", 29)
    val p2 = Person("Alice", 29)
    return p1 == p2
    // Mengembalikan hasil perbandingan antara dua objek Person
    // Dalam kasus ini, p1 dibandingkan dengan p2 apakah nilainya sama
    // Memeriksa apakah p1 dan p2 memiliki nilai 'name' dan 'age' yang sama
    // Output-nya adalah true, karena terlihat isi p1 sama dengan isi p2
}