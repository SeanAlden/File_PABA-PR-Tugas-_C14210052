package Classes

import kotlin.random.Random as KRandom
// Menggunakan alias KRandom untuk kotlin.random.Random
import java.util.Random as JRandom
// Menggunakan alias JRandom untuk java.util.Random

fun useDifferentRandomClasses(): String{
    return "Kotlin random: " +
            KRandom.nextInt(2) +
            // Menggunakan KRandom untuk menghasilkan angka acak dari kotlin.random.Random
            ", Java random: "+
            JRandom().nextInt(2)
            // Menggunakan JRandom untuk menghasilkan angka acak dari java.util.Random
}

fun main() {
    println(useDifferentRandomClasses())
}
