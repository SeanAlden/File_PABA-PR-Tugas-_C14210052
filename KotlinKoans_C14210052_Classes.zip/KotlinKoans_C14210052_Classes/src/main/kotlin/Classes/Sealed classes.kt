package Classes

import java.lang.IllegalArgumentException

sealed class Expr2 {
    // Sealed class Expr2 berfungsi sebagai super class untuk Num2 dan Sum2
    // yang memastikan bahwa semua turunan dari Expr2 dapat dikenali oleh compiler
}

class Num2(val value: Int): Expr2()
// Kelas Num2 yang merupakan turunan dari Expr2 dan menyimpan nilai integer.

class Sum2(val left: Expr2, val right: Expr2): Expr2()
// Kelas Sum2 yang merupakan turunan dari Expr2 dan merepresentasikan operasi penjumlahan
// dimana punya dua properti yaitu left dan right yang dipakai dalam operasi penjumlahan

fun eval2(expr: Expr2): Int =
    when (expr) {
        is Num2 -> expr.value
        // Mengembalikan nilai dari Num2 jika ekspresi adalah Num2
        is Sum2 -> eval2(expr.left) + eval2(expr.right)
        // Mengimplementasikan ekspresi Sum2 dan me-return hasil dari penjumlahannya
        else -> throw IllegalArgumentException("Unknown expression")
    }

fun main(){
    // Penggunaan
    val expression = Sum2(Num2(5), Num2(10))
    val result = eval2(expression)
    println("Hasil evaluasi: $result")
    // Output: Hasil evaluasi: 15
}



