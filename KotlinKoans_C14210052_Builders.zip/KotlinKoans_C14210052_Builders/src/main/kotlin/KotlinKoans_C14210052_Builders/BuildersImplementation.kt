package KotlinKoans_C14210052_Builders

// base class untuk representasi elemen HTML
open class Tag(val name: String) {
    // list untuk child elemen tersebut
    protected val children = mutableListOf<Tag>()
    // function untuk mengkonversi elemen menjadi string HTML
    override fun toString() =
        "<$name>${children.joinToString("")}</$name>"
}

// function untuk membuat elemen tabel dengan fungsi inisialisasi khusus
fun table(init: TABLE.() -> Unit): TABLE {
    val table = TABLE()
    table.init()
    return table
}

// class untuk elemen tabel
class TABLE : Tag("table") {
    // ekstention function untuk menambahkan elemen baris ke dalam elemen tabel
    fun tr(init: TR.() -> Unit) {
        val tr = TR()
            tr.init()
            children += tr
    }
}
// class untuk elemen <tr> yang berfungsi sebagai baris dalam tabel
class TR : Tag("tr") {
    // fungsi ekstensi untuk menambahkan elemen <td> sebagai kolom ke dalam elemen <tr> sebagai baris
    fun td(init: TD.() -> Unit) {
        children += TD().apply(init)
    }
}

// class untuk elemen <td> sebagai kolom didalam tabel
class TD : Tag("td")

// function untuk membuat tabel dengan dua baris dan dua kolom kosong
fun createTable() =
    table {
        tr {
            repeat(2) {
                td {
                }
            }
        }
    }

fun main() {
    println(createTable())
    //<table><tr><td></td><td></td></tr></table>
}