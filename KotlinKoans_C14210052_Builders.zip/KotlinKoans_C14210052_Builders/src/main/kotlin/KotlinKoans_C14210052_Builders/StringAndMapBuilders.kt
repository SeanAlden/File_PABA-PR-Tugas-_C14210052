package KotlinKoans_C14210052_Builders

import java.util.HashMap

// membuat fungsi usage yang dipakai untuk me-return kan map dari tipe Int ke String
fun usage(): Map<Int, String> {
    // call fungsi buildMutableMap dengan lambda sebagai parameter
    return buildMutableMap {
        // menginput pasangan key-value ke dalam map
        put(0, "0")
        // looping yang berisi pasangan dari 1 sampai 10 untuk key-value
        for(i in 1..10){
            put(i, "$i")
        }
    }
}

// generic function untuk membangun Map Mutable
fun <K, V> buildMutableMap(build: HashMap<K, V>.() -> Unit): Map<K, V> {
    // membuat objek HashMap baru
    val map = HashMap<K, V>()
    // call lambda build pada objek map yang baru dibuat
    map.build()
    return map
}

fun main() {
    // call fungsi usage untuk mendapatkan map yang telah dibangun
    val result = usage()
    // output hasil
    println(result)
}