package KotlinKoans_C14210052_Builders.HTML_Builders

// class dasar untuk representasi elemen HTML
open class Tag(val name: String) {
    // list child dari elemen
    val children = mutableListOf<Tag>()
    // list atribut elemen
    val attributes = mutableListOf<Attribute>()

    // fungsi untuk meng-konversi elemen menjadi string
    override fun toString(): String {
        return "<$name" +
                (if(attributes.isEmpty()) "" else attributes.joinToString(separator = "", prefix = " ")) + ">" +
                (if(children.isEmpty()) "" else children.joinToString(separator = "")) +
                "<$name>"
    }
}
// class untuk merepresentasikan atribut dari sebuah elemen HTML
class Attribute(val name: String, val value: String) {
    override fun toString() = """$name="$value" """
}

// ekstention method untuk menambahkan atau mengatur atribut pada sebuah elemen HTML
fun <T : Tag> T.set(name: String, value: String?): T {
    if (value != null) {
        attributes.add(Attribute(name, value))
    }
    return this
}

// fungsi ekstensi untuk menginisialisasi sebuah elemen HTML dengan fungsi inisialisasi khusus
fun <T : Tag> Tag.doInit(tag: T, init: T.() -> Unit): T {
    tag.init()
    children.add(tag)
    return tag
}

// class untuk elemen html
class Html : Tag("html")
// class untuk elemen table
class Table : Tag("table")
// class untuk elemen center
class Center : Tag("center")
// class untuk elemen tr atau baris dalam tabel
class TR : Tag("tr")
// class untuk elemen HTML td atau kolom dalam tabel
class TD : Tag("td")
// class untuk teks yang akan dimasukkan ke dalam elemen HTML
class Text(val text: String) : Tag("b") {
    override fun toString() = text
}

// fungsi untuk membuat elemen html dengan fungsi inisialisasi khusus
fun html(init: Html.() -> Unit): Html = Html().apply(init)

// ekstention function untuk menambahkan elemen table ke dalam elemen html
fun Html.table(init: Table.() -> Unit) = doInit(Table(), init)
// ekstention function untuk menambahkan elemen center ke dalam elemen html
fun Html.center(init: Center.() -> Unit) = doInit(Center(), init)

// ekstention function untuk menambahkan elemen tr (baris) ke dalam elemen table
fun Table.tr(color: String? = null, init: TR.() -> Unit) = doInit(TR(), init).set("bgcolor", color)
// ekstention function untuk menambahkan elemen td (kolom) ke dalam elemen tr (baris)
fun TR.td(color: String? = null, align: String = "left", init: TD.() -> Unit) = doInit(TD(), init).set("align", align).set("bgcolor", color)
// ekstention function untuk menambahkan teks ke dalam sebuah elemen HTML
fun Tag.text(s: Any?) = doInit(Text(s.toString()), {})