package KotlinKoans_C14210052_Builders.HTML_Builders

// fungsi untuk merender tabel produk dalam format HTML
fun renderProductTable(): String {
    return html { // membuat elemen HTML
        table { // membuat elemen tabel
            tr(color = getTitleColor()) {// baris judul tabel
                td {// bagian kolom produk
                    text("Product")
                }
                td {// bagian kolom harga
                    text("Price")
                }
                td {// bagian kolom popularitas
                    text("Popularity")
                }
            }
            // mendapatkan list produk
            val products = getProducts()
            // loop melalui tiap produk
            for ((index, product) in products.withIndex()) {
                tr {// untuk baris setiap produk
                    // kolom untuk deskripsi produk
                    td(color = getCellColor(index, 0)) {
                        text(product.description)
                    }
                    // kolom untuk harga produk
                    td(color = getCellColor(index, 1)) {
                        text(product.price)
                    }
                    // kolom untuk popularitas produk
                    td(color = getCellColor(index, 2)) {
                        text(product.popularity)
                    }
                }
            }
        }
    }.toString() // mengkonversi struktur HTML ke dalam bentuk string
}

// fungsi untuk mendapatkan warna judul
fun getTitleColor() = "#b9c9fe"
// fungsi untuk mendapatkan warna kolom berdasarkan dari indeks baris serta kolom
fun getCellColor(index: Int, column: Int) = if ((index + column) % 2 == 0) "#dce4ff" else "#eff2ff"


fun main() {
    // memanggil fungsi renderProductTable untuk mendapatkan string HTML tabel produk
    val htmlTable = renderProductTable()

    // Output :
    println(htmlTable)
}