package KotlinKoans_C14210052_Builders

// fungsi ini dipakai untuk me-return kan list boolean berdasarkan kondisi bilangan yang diinput
fun task(): List<Boolean> {
    // cek apakah genap
    val isEven: Int.() -> Boolean = {
        this % 2 == 0 // return true jika bilangannya genap dan false jika ganjil
    }
    // cek apakah ganjil
    val isOdd: Int.() -> Boolean = {
        this % 2 != 0 // return true kalau bilangan ganjil dan false jika bilangan genap
    }
    // menggunakan listOf untuk mengecek apa bilangan yang diinput dan membuat list hasil
    return listOf(42.isOdd(), 239.isOdd(), 294823098.isEven())
    // hasilnya: false, true, true
}

fun main() {
    // call function task
    val result = task()
    // output hasil
    println(result)
}