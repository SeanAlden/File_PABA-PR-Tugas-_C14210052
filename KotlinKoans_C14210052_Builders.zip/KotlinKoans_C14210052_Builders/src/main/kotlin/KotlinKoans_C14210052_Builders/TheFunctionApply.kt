package KotlinKoans_C14210052_Builders

// ekstention function bertipe generic yang menerapkan f pada objek caller
fun <T> T.myApply(f: T.() -> Unit): T {
    // memanggil f pada objek caller
    f()
    // mengembalikan objek caller setelah f diterapkan
    return this
}

// function untuk membuat string dengan implementasi StringBuilder
fun createString(): String {
    return StringBuilder().myApply {
        append("Numbers -> ") // append string numbers utk memberitahu bahwa angka akan di outputkan
        // loop untuk mengatur angka dari 1 hingga 10 yang masuk ke string builder
        for (i in 1..10){
            append(i) // menambahkan angka dari 1-10 ke string builder
        }
    }.toString() // mengkonversi StringBuilder menjadi String
}

// fungsi untuk membuat map dengan hashMapOf
fun createMap(): Map<Int, String> {
    return hashMapOf<Int, String>().myApply {
        put(0, "0") // masukkan key-value ke map
        for (i in 1..10){
            put(i, "$i") // masukkan key-value ke map
        }
    }
}

fun main() {
    // call fungsi createString untuk mencetak string
    val stringResult = createString()
    println("String Result: $stringResult")

    // membuat map dengan createMap serta mencetaknya
    val mapResult = createMap()
    println("Map Result: $mapResult")
}
