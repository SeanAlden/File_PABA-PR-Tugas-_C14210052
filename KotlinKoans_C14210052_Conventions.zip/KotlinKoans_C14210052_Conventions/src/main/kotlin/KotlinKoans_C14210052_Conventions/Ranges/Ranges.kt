package KotlinKoans_C14210052_Conventions.Ranges

import KotlinKoans_C14210052_Conventions.MyDate

fun checkInRange(date: MyDate, first: MyDate, last: MyDate): Boolean{
    val range = first..last // Membuat range tanggal menggunakan operator ".."
    return date in range // Memeriksa apakah 'date' berada dalam rentang first sampai last
}

fun main() {
    // Membuat 3 Objek tanggal

    // 1. Objek tanggal yang digunakan untuk mengecek tangal
    val dateToCheck = MyDate(2024, 3, 15)
    // 2. Rentang tanggal start & end
    val startDate = MyDate(2024, 1, 1)
    val endDate = MyDate(2024, 12, 31)

    // variabel yang digunakan untuk mengecek apakah dateToCheck berada dalam rentang
    // tanggal yang ditentukan
    val isInRange = checkInRange(dateToCheck, startDate, endDate)

    // menampilkan hasil

    // Output kalau berada dalam rentang tanggal
    if (isInRange) {
        println("$dateToCheck berada dalam rentang antara $startDate dan $endDate.")
    // Output kalau berada di luar rentang tanggal
    } else {
        println("$dateToCheck tidak berada dalam rentang antara $startDate dan $endDate.")
    }
}