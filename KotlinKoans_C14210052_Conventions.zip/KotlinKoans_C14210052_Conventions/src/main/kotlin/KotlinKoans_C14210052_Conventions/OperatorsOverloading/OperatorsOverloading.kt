package KotlinKoans_C14210052_Conventions.OperatorsOverloading

import KotlinKoans_C14210052_Conventions.MyDate

data class MyDate(val year: Int, val month: Int, val dayOfMonth: Int)

// supported intervals that might be added to dates:
enum class TimeInterval{ DAY, WEEK, YEAR }

// melakukan overload pada operator plus untuk menambahkan
// sebuah time interval ke sebuah tanggal
operator fun MyDate.plus(timeInterval: TimeInterval): MyDate =
    addTimeIntervals(timeInterval, 1)

// sebuah class untuk merepresentasikan time intervals yang diulangi
class RepeatedTimeInterval(val timeInterval: TimeInterval,  val number: Int)

// melakukan overload pada operator waktu untuk membuat sebuah time interval
// yang diulangi
operator fun TimeInterval.times(number: Int) =
    RepeatedTimeInterval(this, number)

// melakukan overload pada operator plus untuk menambahkan sebuah repeated time interval
// ke sebuah tanggal
operator fun MyDate.plus(timeIntervals: RepeatedTimeInterval) =
    addTimeIntervals(timeIntervals.timeInterval, timeIntervals.number)

// fungsi untuk mengimplementasikan task1
// yang akan menambahkan 1 tahun dan 1 minggu ke tanggal yang diberikan tersebut
fun task1(today: MyDate): MyDate {
    return today + TimeInterval.YEAR + TimeInterval.WEEK
}

// fungsi untuk mengimplementasikan task2
// yang akan menambahkan 2 tahun, 3 minggu, dan 5 hari ke tanggal yang diberikan tersebut
fun task2(today: MyDate): MyDate {
    return today + TimeInterval.YEAR * 2 + TimeInterval.WEEK * 3 + TimeInterval.DAY * 5
}

fun main() {
    // membuat sebuah objek tanggal yang disimpan pada variabel today
    // dimana tanggal yang diisi adalah tanggal pada tahun 2024
    val today = MyDate(2024, 2, 10)

    // men-demonstrasikan task1
    val task1Result = task1(today)
    println("Task 1 Result: $task1Result")

    // men-demonstrasikan task2
    val task2Result = task2(today)
    println("Task 2 Result: $task2Result")
}




