package KotlinKoans_C14210052_Conventions.Invoke

class Invokable {
    var numberOfInvocations: Int = 0
        private set

    operator fun invoke(): Invokable {
        // menambah jumlah invokasi setiap kali objek dipanggil
        numberOfInvocations++
        // mengembalikan objek invokable itu sendiri
        return this
    }
}

fun invokeTwice(invokable: Invokable) = invokable()()

fun main() {
    // membuat objek Invokable dan dimasukkan dalam variabel 'invokable'
    val invokable = Invokable()
    // memanggil fungsi invokeTwice dengan set parameter invokable
    // yang merupakan variabel penyimpan objek Invokable
    invokeTwice(invokable)
    // menampilkan jumlah invokasi pada objek Invokable
    println(invokable.numberOfInvocations)
}