package KotlinKoans_C14210052_Conventions.Comparison

import KotlinKoans_C14210052_Conventions.MyDate

fun test(date1: MyDate, date2: MyDate){
    // fungsi ini berfungsi untuk melakukan tes
    // perbandingan pada nilai date1 & date2
    println(date1 < date2)
}

fun main() {
    // Membuat dua objek tanggal yang dimasukkan dalam variabel date1 dan date2
    // untuk diuji
    val date1 = MyDate(2023, 5, 15)
    val date2 = MyDate(2023, 6, 20)

    // Memanggil fungsi test untuk melakukan tes pada persamaan / perbedaan
    // kedua tanggal tersebut
    test(date1, date2)
}