package KotlinKoans_C14210052_Conventions.ForLoop

import java.util.NoSuchElementException

// mendefinisikan kelas DateRange yang
// mengimplementasikan interface Iterable dari MyDate
class DateRange(val start: MyDate, val end: MyDate): Iterable<MyDate> {

    // mengimplementasikan fungsi iterator dari interfae Iterator
    override fun iterator(): Iterator<MyDate> {

        // membuat objek anonim yang mengimplementasikan interface Iterator untuk MyDate
        return object : Iterator<MyDate> {

            // inisialisasi variabel current untuk tanggal awal
            var current: MyDate = start

            // mengimplementasikan fungsi next dari interface Iterator
            // dengan menggunakan konsep override
            override fun next(): MyDate {
                // berfungsi jika tidak ada elemen selanjutnya yang ditemukan
                if (!hasNext()) throw NoSuchElementException()
                // menyimpan nilai tanggal saat ini
                val result = current
                // mendapatkan tanggal berikutnya dan memperbarui current
                current = current.followingDate()

                return result
            }
            // mengimplementasikan fungsi hasNext dari
            // interface Iterator untuk menentukan apakah ada elemen berikutnya
            override fun hasNext(): Boolean = current <= end
        }
    }
}

fun main() {
    // membuat objek MyDate untuk tanggal awal dan tanggal akhir
    val startDate = MyDate(2024, 1, 1)
    val endDate = MyDate(2024, 1, 10)

    // membuat objek DateRange dengan tanggal awal dan tanggal akhir
    val dateRange = DateRange(startDate, endDate)

    // menggunakan for loop untuk mencetak setiap tanggal dalam rentang tanggal
    for (date in dateRange){
        println(date)
    }
}