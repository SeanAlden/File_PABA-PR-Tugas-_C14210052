package KotlinKoans_C14210052_Conventions.ForLoop

data class MyDate(val year: Int, val month: Int, val dayOfMonth: Int): Comparable<MyDate>{
    override fun compareTo(other: MyDate): Int {
        // Membandingkan tahun terlebih dahulu
        if (year != other.year) return year - other.year
        // Membandingkan bulan, jika tahun ditemukan sama
        if (month != other.month) return month - other.month
        // Membandingkan hari (tanggal), jika bulan ditemukan sama
        return dayOfMonth - other.dayOfMonth
    }
}

// berfungsi untuk membuat sebuah extension function yaitu 'rangeTo' untuk tipe data MyDate
operator fun MyDate.rangeTo(other: MyDate) = DateRange(this, other)

