package KotlinKoans_C14210052_Conventions.ForLoop

import KotlinKoans_C14210052_Conventions.ForLoop.MyDate
import java.util.Calendar

/*
 * Returns the following date after the given one.
 * For example, for Dec 31, 2019 the date Jan 1, 2020 is returned.
 */

// fungsi extension untuk menghitung tanggal berikutnya dari tanggal saat ini
fun MyDate.followingDate(): MyDate {
    // mendapatkan instance Calendar untuk menangani tanggal
    val c = Calendar.getInstance()
    // menetapkan tanggal yang telah diatur dan dimasukkan dalam instance
    c.set(year, month, dayOfMonth)
    // atur jumlah milidetik dalam sehari
    val millisecondsInADay = 24 * 60 * 60 * 1000L
    // perhitungan waktu dalam milidetik untuk tanggal berikutnya
    val timeInMillis = c.timeInMillis + millisecondsInADay
    // instance Calendar untuk tanggal result
    val result = Calendar.getInstance()
    // waktu dalam milidetik ke instance result
    result.timeInMillis = timeInMillis
    // membuat dan me-return objek MyDate yang mewakili tanggal berikutnya
    return MyDate(result.get(Calendar.YEAR), result.get(Calendar.MONTH), result.get(Calendar.DATE))
}