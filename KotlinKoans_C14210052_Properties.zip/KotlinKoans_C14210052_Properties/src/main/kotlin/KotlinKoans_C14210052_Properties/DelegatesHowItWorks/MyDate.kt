package KotlinKoans_C14210052_Properties.DelegatesHowItWorks

import java.util.Calendar

// data class MyDate yang mengimplementasikan tanggal
data class MyDate(val year: Int, val month: Int, val dayOfMonth: Int)

// fungsi ekstensi untuk mengonversi MyDate menjadi Long
fun MyDate.toMillis(): Long{
    val c = Calendar.getInstance()
    // menetapkan tahun, bulan, dan tanggal
    c.set(year, month, dayOfMonth)
    // me-return kan waktu dalam milisekon
    return c.getTimeInMillis()
}

// fungsi ekstensi yg dipakai untuk mengonversi Long menjadi MyDate
fun Long.toDate(): MyDate {
    val c = Calendar.getInstance()
    // menetapkan waktu dengan nilai Long yg diberikan
    c.setTimeInMillis(this)
    return MyDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DATE))
}