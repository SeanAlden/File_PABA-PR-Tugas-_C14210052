package KotlinKoans_C14210052_Properties.DelegatesHowItWorks

import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

// class D menggunakan delegasi by untuk properti date
class D {
    var date: MyDate by EffectiveDate()
}

// class EffectiveDate yang mengimplementasikan ReadWriteProperty
class EffectiveDate<R> : ReadWriteProperty<R, MyDate> {

    var timeInMillis: Long? = null

    // implementasi getter untuk properti, serta mengonversi timeInMillis menjadi MyDate
    override fun getValue(thisRef: R, property: KProperty<*>): MyDate{
        return timeInMillis!!.toDate()
    }

    // implementasi setter untuk properti, mengonversi MyDate menjadi timeInMillis
    override fun setValue(thisRef: R, property: KProperty<*>, value: MyDate){
        timeInMillis = value.toMillis()
    }
}

fun main() {
    // membuat objek dari class D
    val d = D()

    // membuat objek MyDate dengan memasukkan tanggal yg dipilih
    val myDate = MyDate(2024, 3, 4)

    // mengatur properti date dengan objek MyDate yang telah dibuat
    d.date = myDate

    // mencetak tanggal yang telah diatur
    println(d.date)
}