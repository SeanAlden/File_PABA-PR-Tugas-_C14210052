package KotlinKoans_C14210052_Properties

// class LazyProperty dengan konstruktor yang menerima lambda untuk
// inisialisasi nilai
class LazyProperty(val initializer: () -> Int){

    // properti value bertipe Int nullable untuk
    // menyimpan nilai yang diinisialisasi secara 'lazy'
    var value: Int? = null

    // properti lazy bertipe
    // Int dengan getter kustom
    val lazy: Int
        get() {
            // jika value belum diinisialisasi, inisialisasi dengan
            // nilai yang dikembalikan oleh lambda initializer
            if (value == null){
                value = initializer()
            }
            // me-return kan nilai dari value
            return value!!
        }
}

fun main() {
    // membuat objek dari kelas LazyProperty dengan lambda inisialisasi
    val lazyProperty = LazyProperty {
        // pesan yg akan di output-kan saat nilai diinisialisasi
        println("Lazy property initialized")
        // nilai yang akan diinisialisasi
        42
    }
    // penggunaan properti lazy

    // Output:
    // Lazy property initialized
    // 42
    println(lazyProperty.lazy)

    // hanya akan meng-outputkan 42 karena nilai sudah diinisialisasi sebelumnya
    println(lazyProperty.lazy)
}