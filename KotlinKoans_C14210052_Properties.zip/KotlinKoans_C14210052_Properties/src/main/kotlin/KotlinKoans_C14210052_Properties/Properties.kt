package KotlinKoans_C14210052_Properties

class PropertyExample(){
    // menginisialisasi counter
    var counter = 0
    // properti dengan kustom getter dan setter
    var propertyWithCounter: Int? = null

        // setter kustom untuk properti yg telah dibuat diatas
        set(v){
            field = v // menetapkan nilai properti
            counter++ // menambahkan 1 ke counter setiap kali nilai properti diubah
        }
}

fun main() {
    // membuat objek dari kelas PropertyExample
    val example = PropertyExample()
    // memasukkan nilai ke dalam properti propertyWithCounter
    example.propertyWithCounter = 42
    // output untuk nilai properti propertyWithCounter
    println("Nilai propertyWithCounter: ${example.propertyWithCounter}")
    // output untuk jumlah pembaruan counter
    println("Counter: ${example.counter}")
}