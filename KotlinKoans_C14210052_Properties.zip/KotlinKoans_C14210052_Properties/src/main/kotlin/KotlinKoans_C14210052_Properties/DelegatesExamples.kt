package KotlinKoans_C14210052_Properties

// class dengan konstruktor menerima lambda untuk inisialisasi nilai
class LazyProperty2(val initializer: () -> Int){

    // properti lazyValue bertipe integer yang diinisialisasi menggunakan delegasi by lazy
    val lazyValue: Int by lazy(initializer)
}

fun main() {
    // membuat objek dari kelas LazyProperty2 dengan lambda inisialisasi
    val lazyProperty2 = LazyProperty2 {
        println("Lazy property initialized")
        42
    }
    // Output
    println(lazyProperty2.lazyValue)
    println(lazyProperty2.lazyValue)
}