fun main() {
    print("Melakukan print tanpa enter")
    println("Melakukan print dengan enter")
    println("Hello World 1"); print("Hello World 2")

    println(jumlah(0,3))
    // Memanggil fungsi jumlah yang akan
    // menjumlahkan parameter a yaitu "0"
    // dengan parameter b yaitu "3"
    println(bagi(6,3))
    // Memanggil fungsi bagi yang akan
    // membagi parameter a yaitu "6"
    // dengan parameter b yaitu "3" -> Hasil = 2

    println(bagi(b=4))
    // Melakukan set pada parameter b menjadi 4
    // sehingga program akan melakukan operasi: 3/4
    // yang sama dengan 0 karena "3" merupakan nilai
    // default dari fungsi "bagi"
    println(bagi(b=4, a=2))
    // Melakukan pembagian a/b yaitu 2/4 yang
    // akan menghasilkan nilai 0

    var array1 = arrayOf("z", "y")
    // membuat array yang memiliki bentuk syntax lain yaitu java menjadi
    // String[] array1 = {"z", "Y"};
    // memakai var, dimana merupakan tipe data mutable (nilainya dapat diubah)
    stringGabung("a", "b", *array1)
    // penggunaan fungsi "stringGabung" yang akan menerima parameter varargs
    // (variadic arguments) bertipe string.

    // Menggabungkan "a" dan "b" dengan isi dari array1
    // menuliskan bintang atau asteris didepan array1 saat ditulis dalam fungsi
    // stringGabung agar tiap elemen dalam array tersebut dapat dianggap sebagai argumen
    // terpisah dan digabung dengan "a" dan "b"
    // mengoutputkan: a, b, z, y
    // dimana isi array1 adalah "z" dan "y"


    var tanggal = 28
    // inisialisasi variable tanggal bersifat mutable dgn value 28
    var bulan = "Feb"
    // inisialisasi variable bulan bersifat mutable dgn value "string"

    println("${tanggal+1} $bulan")
    println(bulan[1])

    var nama= """
    Pelajaran
    Android"""
    println(nama)

    println(2.times(3))
    println(3.5.plus(3))
    println(2.4.div(2))

    var array1_2 = arrayOf(1,2,3, 4.0, "a")
    println(array1_2.joinToString())

    var array2 :Array<Int?> = arrayOfNulls(3)
    println(array2.joinToString())

    var array3 = emptyArray<String>()
    println(array3.joinToString())

    var array4 = Array(2) {Array<Int>(2){0}}
    println (array4.contentDeepToString())

    var array5 = Array(5) {i -> (i*i).toString()}
    println(array5.joinToString())
    array5.forEach{print(it + " ")}
    println("")

    println(array5[2])
    array5[2] = "8"
    array5.forEach{print(it+" ")}
    println("")

    var array6 = Array(15) {i -> (i+1)}
    println(array6.joinToString())
    array6.shuffle()
    println(array6.joinToString())
    println(array6.sum())

    var array7 = arrayOf("a","n","d","r","o","i","d")
    println(array7.toSet())
    println(array7.toList())

    var array8 = arrayOf("android" to 10, "ios" to 5, "web" to 7)
    println(array8.toMap())
    array8.shuffle()
    println(array8.toMap())



}

fun jumlah(a :Int, b:Int): Int{
    return a+b
    // fungsi jumlah dengan set nilai parameter a bertipe integer
    // , dan parameter b bertipe integer, yang kemudian mereturn nilai jumlah (a+b)
}

fun bagi(a:Int=3, b:Int) = a/b
    // fungsi bagi dengan set nilai a adalah integer dan b adalah integer
    // dengan return nilai bagi (a/b)

fun stringGabung(vararg s : String) {
    println(s.joinToString())
    // penggunaan fungsi "joinToString()" untuk menggabungkan semua string
    // yang diterima sebagai argumen menjadi satu string, yang di pisah per string nya
    // dengan tanda koma (')
    // misal: a, b, z, y // output ke-5 pada source code ini
    // Varargs  berguna utk mengirim sejumlah argumen yang bervariasi
    // ke dalam fungsi tanpa harus mendefinisikan jumlah pasti dari
    // parameter tersebut di deklarasi fungsi.
}
