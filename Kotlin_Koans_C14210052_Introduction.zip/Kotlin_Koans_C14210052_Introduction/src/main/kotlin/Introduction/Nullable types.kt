package Introduction

fun sendMessageToClient(
    client: Client?, // Parameter client bisa null
    message: String?, // Parameter message bisa null
    mailer: Mailer
){
    val email = client?.personalInfo?.email // Mengakses email dari client, bisa null
    if (email != null && message != null){ // Melakukan pengecekan apakah email dan message tidak null
        mailer.sendMessage(email, message) // Mengirim pesan jika email dan message tidak null
    }
    // Jika salah satu dari email atau message null, pesan tidak dikirim
}

class Client(val personalInfo: PersonalInfo?) // membuat class Client dengan parameter personalInfo, tipe data PersonalInfo type null
class PersonalInfo(var email: String?) // membuat class PersonalInfo dengan parameter email, tipe data String type null
interface Mailer{
    fun sendMessage(email: String, message: String)
}
// membuat interface Mailer yang berisi fungsi / method sendMessage parameternya email (String) dan message (String)


fun main() {
    val client = Client(PersonalInfo("adi77@gmail.com")) // set value email
    val message = "Hello, how are you?" // set message yg ditampilkan
    val mailer = object : Mailer { // memanggil interface Mailer yang ditampung pada variabel object
        override fun sendMessage(email: String, message: String) {
            // fungsi override dari interface Mailer
            println("Sending message to $email: $message")
            // print email dan pesan
        }
    }
    // fungsi mengirim pesan pada client
    sendMessageToClient(
        client,
        message,
        mailer
    )
}