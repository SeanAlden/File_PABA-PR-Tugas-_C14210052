package Introduction

fun start(): String = "Hello World"

fun main(){
    println(start())

    print("tanpa enter") // tanpa enter / newline
    print(" tanpa enter") // tanpa enter / newline
    print("\n") // enter manual
    println("dengan enter") // dengan enter
    println("dengan enter") // dengan enter
}