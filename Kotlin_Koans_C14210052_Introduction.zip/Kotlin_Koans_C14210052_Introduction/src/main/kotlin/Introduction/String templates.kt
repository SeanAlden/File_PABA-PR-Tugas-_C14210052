package Introduction

val month = "(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)"
// variabel month yang berisi bulan-bulan dalam setahun

fun getPattern(): String = """\d[2] $month \d"""// implementasi string template

fun main() {
    println(getPattern())
    // melakukan print pada string template
}