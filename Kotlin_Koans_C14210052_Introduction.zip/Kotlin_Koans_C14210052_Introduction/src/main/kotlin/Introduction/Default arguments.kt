package Introduction

fun main() {
    call() // output: Hello Adi
    call("Budi") // output: Hello Budi

    val results = useFoo() // membuat variabel yang memanggil fungsi useFoo
    results.forEach{
        println(it)
    }
}

fun call(name: String = "Adi"){ // membuat fungsi dengan argumen default nya adalah 'Adi'
    println("Hello $name") // print output: Hello Adi
}

fun foo(name: String = "", number: Int = 0, toUpperCase: Boolean = false): String{
    // Menggunakan argumen default untuk parameter 'name', 'number', dan 'toUpperCase'
    val modifiedName = if (toUpperCase) name.toUpperCase() else name
    return modifiedName + number
}

fun useFoo() = listOf(
    foo(),
    // Memanggil 'foo' tanpa argumen, sehingga menggunakan nilai default untuk semua parameter
    foo("b", number = 1),
    // Memanggil 'foo' dengan memberikan nilai name = "b", number = 1
    // dan toUpperCase dengan menggunakan default nilainya yaitu 'false'
    foo("c", toUpperCase = true),
    // Memanggil 'foo' dengan name = "c", dan men-set nilai toUpperCase menjadi true
    // sementara nilai untuk number nya memakai default yaitu 0
    foo(name = "d", number = 2, toUpperCase = true)
    // Memanggil 'foo' dengan semua parameter diberi nilai dan didefinisikan
    // secara eksplisit
)

