package Introduction

fun main() {
    call() // output: Hello Adi
    call("Budi") // output: Hello Budi
}

fun call(name: String = "Adi"){ // membuat fungsi dengan argumen default nya adalah 'Adi'
    println("Hello $name") // print output: Hello Adi
}

