package Introduction

fun containsEven(collection: Collection<Int>): Boolean =
    collection.any{it % 2 == 0}
    // Menggunakan lambda "it" untuk memeriksa apakah terdapat angka genap / kelipatan 2

fun main() {
    val numbers = listOf(1, 2, 3, 4, 5)
    println("Apakah koleksi mengandung angka yang genap? ${containsEven(numbers)}")
}