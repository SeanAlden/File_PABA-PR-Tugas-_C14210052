package Introduction

import java.lang.IllegalArgumentException

fun failWithWrongAge(age: Int?): Nothing{
    // Fungsi ini akan melempar IllegalArgumentException dengan pesan yang mengoutputkan usia yang salah
    throw IllegalArgumentException("Wrong age: $age")
}

fun checkAge(age: Int?){
    // Memeriksa apakah usia berada dalam rentang yang valid (0 sampai 150)
    if (age == null || age !in 0..150) failWithWrongAge(age)
    // Kalau usia valid, maka akan meng-outputkan kata" selamat serta memberitahu usia tahun depan
    println("Congrats! Next year you'll be ${age + 1}")
}

fun main() {
    // Melakukan set pada parameter fungsi checkAge yaitu 10
    checkAge(10)
}
