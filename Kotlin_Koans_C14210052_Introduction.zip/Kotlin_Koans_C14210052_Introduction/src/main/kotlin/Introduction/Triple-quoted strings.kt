package Introduction

const val question = "life, the universe, and everything"
// nilai variabel konstanta yang immutable (tidak dapat dirubah)
const val answer = 42
// nilai variabel konstanta yang immutable (tidak dapat dirubah)

val tripleQuotedString = """
    #question = "$question"
    #answer = $answer""".trimIndent()
// trimIndent() berfungsi untuk manipulasi string, dimana menghapus setiap
// indentasi setiap baris dalam string, agar kontennya tidak dimulai dari space
// tambahan yang tidak diperlukan

// kode diatas adalah implementasi dari multi-string yang membuat
// kita dapat menuliskan string lebih dari 1 baris tanpa perlu karakter \n atau newline
// cara penulisannya adalah dengan """ string """

// keuntungan: gampang untuk menuliskan string panjang tanpa harus
// sering memakai format string atau tanda escape

fun main() {
    println(tripleQuotedString)
}