package Introduction

fun printUserInfo(name: String, age: Int, city: String){
    println("Name: $name, Age: $age, City: $city")
    // format untuk print
}

fun joinOptions(options: Collection<String>) =
    options.joinToString(
        separator = ", ", // set separator
        prefix = "[", // set prefix
        postfix = "]" // set postfix
    )

fun main(){
    // Memanggil fungsi diatas dengan named arguments
    printUserInfo(name = "John", age = 20, city = "Surabaya")
    // output: Name: John, Age: 20, City: Surabaya
    val options = listOf("Pilih 1", "Pilih 2", "Pilih 3")
    // Memanggil fungsi joinOptions dengan memakai named arguments
    val joinedOptions = joinOptions(options)
    println(joinedOptions)
    // outputnya adalah:
    // [Pilih 1, Pilih 2, Pilih 3]
}


