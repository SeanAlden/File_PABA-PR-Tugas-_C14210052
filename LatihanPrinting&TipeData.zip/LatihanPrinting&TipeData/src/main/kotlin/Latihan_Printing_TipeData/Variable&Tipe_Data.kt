package Latihan_Printing_TipeData

fun main() {
    // membuat variabel
    // tipe data
    var a = 10 //assignment
    // tipe data var berarti mutable (dapat diubah)
    println("nilai a = $a")

    a = 20 // dirubah jadi 20
    println("nilai a baru = $a")

    val z = 5
    // z = 7 //tidak dapat dilakukan, karena tipe data dengan val bersifat immutable

    // kita akan membuat sebuah deklarasi

    // deklarasi
    var int: Int // tipe data integer
    var string: String // tipe data string
    var boolean: Boolean // tipe data boolean
    var double: Double // tipe data double
    var float: Float // tipe data float
    var short: Short // tipe data short
    var long: Long // tipe data long
    var char: Char // tipe data char
    var byte: Byte // tipe data byte

    var arrayInt: Array<Int> // tipe data array integer
    var arrayString: Array<String> // tipe data array string
    var arrayDouble: Array<Double> // tipe data array boolean
    var arrayFloat: Array<Float> // tipe data array float
    var arrayShort: Array<Short> // tipe data array short
    var arrayLong: Array<Long> // tipe data array long
    var arrayChar: Array<Char> // tipe data array char
    var arrayByte: Array<Byte> // tipe data array byte
    val arrayBoolean: Array<Boolean> // tipe data array boolean

    // inisialisasi value
    int = 7
    string = "Kotlin"
    boolean = true
    double = 3.5
    float = 7f
    short = 10
    long = 10L
    char = 'a'
    byte = 10

    // penggunaan dan inisialisasi data array
    arrayInt = arrayOf(1, 2, 3, 4, 5)
    arrayString = arrayOf("Kotlin", "Java", "Python")
    arrayDouble = arrayOf(1.5, 2.5, 3.5)
    arrayFloat = arrayOf(1.1f, 2.2f, 3.3f)
    arrayShort = arrayOf<Short>(1, 2, 3, 4, 5)
    arrayLong = arrayOf<Long>(10L, 20L, 30L, 40L, 50L)
    arrayChar = arrayOf<Char>('a', 'b', 'c', 'd', 'e')
    arrayByte = arrayOf<Byte>(10, 11, 12, 13, 14, 15)
    arrayBoolean = arrayOf<Boolean>(true, false, true, false)

    // menampilkan value
    println("nilai int = $int")
    println("nilai string = $string")
    println("nilai boolean = $boolean")
    println("nilai double = $double")
    println("nilai float = $float")
    println("nilai short = $short")
    println("nilai long = $long")
    println("nilai char = $char")
    println("nilai byte = $byte")

    println(" ")

    // menampilkan nilai array
    println("nilai arrayInt = ${arrayInt.joinToString()}")
    println("nilai arrayString = ${arrayString.joinToString()}")
    println("nilai arrayDouble = ${arrayDouble.joinToString()}")
    println("nilai arrayFloat = ${arrayFloat.joinToString()}")
    println("nilai arrayShort = ${arrayShort.joinToString()}")
    println("nilai arrayLong = ${arrayLong.joinToString()}")
    println("nilai arrayChar = ${arrayChar.joinToString()}")
    println("nilai arrayByte = ${arrayByte.joinToString()}")
    println("nilai arrayBoolean = ${arrayBoolean.joinToString()}")


    // tipe data di kotlin:
    // integer, byte, short, long, double, float, char, boolean

    // integer (satuan)
    val i = 10
    println("======INTEGER======")
    println("nilai integer i = ${i + 1}")
    println("nilai max = ${Int.MAX_VALUE}")
    println("nilai min = ${Int.MIN_VALUE}")
    println("Besar integer = ${Int.SIZE_BYTES} bytes")
    println("Besar integer = ${Int.SIZE_BITS} bit")

    // byte (satuan)
    val b: Byte = 10
    println("======BYTE======")
    println("nilai byte b = $b")
    println("Nilai max = ${Byte.MAX_VALUE}")
    println("Nilai min = ${Byte.MIN_VALUE}")
    println("Besar byte = ${Byte.SIZE_BYTES} bytes")
    println("Besar byte = ${Byte.SIZE_BITS} bit")

    // short (satuan)
    val s: Short = 10
    println("======SHORT======")
    println("nilai short s = $s")
    println("Nilai max = ${Short.MAX_VALUE}")
    println("Nilai min = ${Short.MIN_VALUE}")
    println("Besar short = ${Short.SIZE_BYTES} bytes")
    println("Besar short = ${Short.SIZE_BITS} bit")

    // long (satuan)
    val l = 10L
    println("======LONG======")
    println("nilai long l = $l")
    println("Nilai max = ${Long.MAX_VALUE}")
    println("Nilai min = ${Long.MIN_VALUE}")
    println("Besar long = ${Long.SIZE_BYTES} bytes")
    println("Besar long = ${Long.SIZE_BITS} bit")

    // double (koma, bilangan real)
    val d = -10.5
    println("======DOUBLE======")
    println("nilai double d = $d")
    println("Nilai max = ${Double.MAX_VALUE}")
    println("Nilai min = ${Double.MIN_VALUE}")
    println("Besar double = ${Double.SIZE_BYTES} bytes")
    println("Besar double = ${Double.SIZE_BITS} bit")

    // float (koma, bilangan real)
    val f = -8.5f
    println("======FLOAT======")
    println("nilai float f = $f")
    println("Nilai max = ${Float.MAX_VALUE}")
    println("Nilai min = ${Float.MIN_VALUE}")
    println("Besar float = ${Float.SIZE_BYTES} bytes")
    println("Besar float = ${Float.SIZE_BITS} bit")

    // char (karakter) berdasarkan ASCII
    val c: Char = 'c'
    println("======CHAR======")
    println("nilai char c = $c")
    println("Nilai max = ${Char.MAX_VALUE}")
    println("Nilai min = ${Char.MIN_VALUE}")
    println("Besar char = ${Char.SIZE_BYTES} bytes")
    println("Besar char = ${Char.SIZE_BITS} bit")

    // boolean (nilai true atau false)
    val valBoolean = false
    println("======BOOLEAN======")
    println("nilai boolean val = $valBoolean")

}

