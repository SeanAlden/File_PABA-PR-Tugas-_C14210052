package Latihan_Printing_TipeData

fun main(args: Array<String>) {

    print("Hello World") // Tanpa Enter
    println(" Hello World 2") // Dengan Enter

    println("Hello World 3")
    println("Hello World 4")

    print("Enter dengan slash n\n")
    println("Enter dengan slash n\n") // Enter 2 kali
    print("Hello World 5")

    println("\n") // Enter 2 kali

    printf("belajar android pertemuan %d", 1)
    // persen d (%d) digunakan untuk menampilkan variabel yang ditulis
    // setelah koma, misalnya pada cth diatas yaitu: 1

    println("hallo ${args.getOrNull(0)} adi")
    println("hallo ${args.getOrNull(1)} budi")
    // diatas adalah penggunaan args pada print

}

fun printf(format: String, value: Int){
    println(String.format(format, value))
}