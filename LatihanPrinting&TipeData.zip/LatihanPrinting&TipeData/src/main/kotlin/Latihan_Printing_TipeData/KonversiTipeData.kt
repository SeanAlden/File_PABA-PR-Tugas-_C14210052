package Latihan_Printing_TipeData

fun main(){

    // program untuk konversi data

    val nilaiInt = 450 //32-bit
    println("nilai int = $nilaiInt")

    // Memperluas rentang ke tipe data yang lebih besar
    val nilaiLong: Long = nilaiInt.toLong()
    println("nilai long = $nilaiLong")

    // Memperkecil rentang ke tipe data yang lebih kecil
    val nilaiByte: Byte = nilaiInt.toByte()
    println("nilai byte = $nilaiByte")
    println("nilai max byte = ${Byte.MAX_VALUE}")
    println("nilai min byte = ${Byte.MIN_VALUE}")

    // casting pembagian
    val a = 10
    val b = 4f

    // membuat variabel c yang akan melakukan pembagian antara a dgn b
    val c = a / b

    // print hasil pembagian dengan tanda solar '$' untuk mengakses
    // variabel yg dituju (misal '$a / $b = $c' berarti value a / value b = value c
    println("$a / $b = $c")

    val x = 10
    val y = 4

    // merubah tipe data x ke float yg berupa val (untuk merubah tipe data bisa dilakukan, tidak bisa untuk merubah value)
    val z = x.toFloat()/y
    println("$x / $y = $z")
}