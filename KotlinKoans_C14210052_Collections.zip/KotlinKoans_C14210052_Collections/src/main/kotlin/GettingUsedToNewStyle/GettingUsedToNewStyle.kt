package GettingUsedToNewStyle

fun doSomethingWithCollection(collection: Collection<String>): Collection<String>? {
    // mengelompokkan elemen collection berdasarkan panjang string
    val groupsByLength = collection.groupBy { s -> s.length }
    // menemukan ukuran maksimum dari grup
    val maximumSizeOfGroup = groupsByLength.values.map { group -> group.size }.maxOrNull()
    // mengembalikan grup pertama yang memiliki ukuran yang sama dengan ukuran maksimum
    return groupsByLength.values.firstOrNull { group -> group.size == maximumSizeOfGroup }
}

fun main() {
    // membuat list dengan isi nama buah
    val collection = listOf("apple", "banana", "orange", "kiwi", "pear", "peach")

    // memakai fungsi doSomethingWithCollection pada list yg telah dibuat
    // dan disimpan pada variabel result
    val result = doSomethingWithCollection(collection)
    println("Result: $result")
}
