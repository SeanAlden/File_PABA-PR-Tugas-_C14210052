package AllAnyAndOtherPredicates

// Return true if all customers are from a given city
fun Shop.checkAllCustomersAreFrom(city: City): Boolean {
    return customers.all { it.city == city }
}

// Return true if there is at least one customer from a given city
fun Shop.hasCustomerFrom(city: City): Boolean {
    return customers.any { it.city == city }
}

// Return the number of customers from a given city
fun Shop.countCustomersFrom(city: City): Int {
    return customers.count { it.city == city }
}

// Return a customer who lives in a given city, or null if there is none
fun Shop.findCustomerFrom(city: City): Customer? {
    return customers.find { it.city == city }
}

fun main() {
    val city1 = City("City 1")
    val city2 = City("City 2")

    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), true)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // menggunakan fungsi checkAllCustomersAreFrom
    val checkAllCustomersFromCity1 = shop.checkAllCustomersAreFrom(city1)
    println("Are all customers from City 1? $checkAllCustomersFromCity1")

    // menggunakan fungsi hasCustomerFrom
    val hasCustomerFromCity2 = shop.hasCustomerFrom(city2)
    println("Is there any customer from City 2? $hasCustomerFromCity2")

    // menggunakan fungsi countCustomersFrom
    val countCustomerFromCity1 = shop.countCustomersFrom(city1)
    println("Number of customers from City 1: $countCustomerFromCity1")

    // menggunakan fungsi findCustomerFrom
    val customerFromCity2 = shop.findCustomerFrom(city2)
    println("Customer from City 2: $customerFromCity2")
}