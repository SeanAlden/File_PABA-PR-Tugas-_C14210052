package Associate

// data class Shop dengan properti nama dan list pelanggan
data class Shop(val name: String, val customers: List<Customer>)

// data class Customer dengan properti nama, kota, dan list pesanan
data class Customer(val name: String, val city: City, val orders: List<Order>){
    // melakukan override fungsi toString untuk menampilkan nama pelanggan dan nama kota
    override fun toString() = "$name from ${city.name}"
}

// data class Order dengan properti list produk dan status pengiriman dengan tipe data boolean (true/false)
data class Order(val products: List<Product>, val isDelivered: Boolean)

// data class Product dengan properti nama dan harga
data class Product(val name: String, val price: Double){
    // override fungsi toString untuk menampilkan nama produk & harganya
    override fun toString() = "'$name' for $price"
}

// data class City dengan properti nama kota
data class City(val name: String){
    // override fungsi toString untuk menampilkan nama kota
    override fun toString() = name
}