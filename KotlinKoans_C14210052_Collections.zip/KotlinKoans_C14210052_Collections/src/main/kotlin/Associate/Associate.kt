package Associate

// membuat peta dari nama customer ke customer itu sendiri
fun Shop.nameToCustomerMap(): Map<String, Customer> {
    // memakai fungsi associateBy untuk mengaitkan setiap customer dengan namanya
    return customers.associateBy { it.name }
}

// membuat peta dari customer ke kota mereka
fun Shop.customerToCityMap(): Map<Customer, City> {
    // memakai fungsi associate untuk mengaitkan setiap customer dengan kota tempat tinggalnya
    return customers.associate { it to it.city }
}

// membuat peta dari nama customer ke kota mereka
fun Shop.customerNameToCityMap(): Map<String, City> {
    // memakai fungsi associate untuk mengaitkan setiap nama customer dengan kota tempat tinggalnya
    return customers.associate { it.name to it.city }
}

fun main() {
    // membuat dua objek City yg di save di city1 dan city2
    val city1 = City("City 1")
    val city2 = City("City 2")

    // membaut tiga objek Customer dengan pesanan yang berbeda dan kota yang berbeda
    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), true)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    // membuat objek Shop dengan list pelanggan yang telah didefinisikan sebelumnya
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // membuat variabel nameToCustomerMap untuk mengimplementasikan fungsi nameToCustomerMap
    // serta membangun peta dari nama customer ke customer itu sendiri
    val nameToCustomerMap = shop.nameToCustomerMap()
    println("Name to Customer Map:")
    println(nameToCustomerMap)

    // menggunakan fungsi customerToCityMap untuk membangun peta dari customer ke kota mereka
    val customerToCityMap = shop.customerToCityMap()
    println("\nCustomer to City Map:")
    println(customerToCityMap)

    // menggunakan fungsi customerNameToCityMap untuk membangun peta dari nama customer ke kota mereka
    val customerNameToCityMap = shop.customerNameToCityMap()
    println("\nCustomer Name to City Map:")
    println(customerNameToCityMap)
}