package Sort

fun Shop.getSetOfCustomers(): Set<Customer> {
    // menggunakan ekstensi properties customers untuk mengambil semua pelanggan dari shop dan mengubahnya menjadi Set
    return customers.toSet()
}

fun Shop.getCustomersSortedByOrders(): List<Customer> {
    // mengembalikan daftar pelanggan yang diurutkan berdasarkan jumlah pesanan yang mereka miliki
    // diurutkan dari jumlah pesanan terbanyak
    return customers.sortedByDescending { it.orders.size }
}

fun main() {
    val city1 = City("City 1")
    val city2 = City("City 2")

    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), true)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // Menggunakan fungsi getSetOfCustomers untuk mendapatkan set pelanggan yang unik dan diurutkan
    val setOfCustomers = shop.getSetOfCustomers()
    println("Set of Customers:")
    println(setOfCustomers)

    // menggunakan fungsi getCustomersSortedByOrders untuk
    // mendapatkan daftar pelanggan yang diurutkan berdasarkan jumlah pesanan
    val customersSortedByOrders = shop.getCustomersSortedByOrders()
    println("\nCustomers Sorted by Orders:")
    println(customersSortedByOrders)
}