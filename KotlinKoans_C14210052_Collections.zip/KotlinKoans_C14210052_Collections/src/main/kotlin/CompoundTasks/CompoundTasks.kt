package CompoundTasks

// Find the most expensive product among all the delivered products
// ordered by the customer. Use `Order.isDelivered` flag.
fun findMostExpensiveProductBy(customer: Customer): Product? {
    return customer
        .orders
        // filter hanya pesanan yang telah dikirim
        .filter(Order::isDelivered)
        // ambil semua produk dari pesanan yang telah dikirim
        .flatMap(Order::products)
        // menemukan produk paling mahal
        .maxByOrNull(Product::price)
}


// Count the amount of times a product was ordered.
// Note that a customer may order the same product several times.
fun Shop.getNumberOfTimesProductWasOrdered(product: Product): Int {
    return customers
        // mengambil semua produk yang dipesan oleh semua customer
        .flatMap(Customer::getOrderedProducts)
        // menghitung berapa kali produk tersebut muncul
        .count { it == product }
}

// function ekstensi untuk mendapatkan semua produk yang dipesan oleh customer
fun Customer.getOrderedProducts(): List<Product> =
    orders.flatMap(Order::products)

fun main() {
    val product1 = Product("Product 1", 10.0)
    val product2 = Product("Product 2", 20.0)
    val product3 = Product("Product 3", 30.0)

    val customer1 = Customer("Customer 1", City("City 1"), listOf(Order(listOf(product1, product2), true)))
    val customer2 = Customer("Customer 2", City("City 2"), listOf(Order(listOf(product2, product3), true)))
    val customer3 = Customer("Customer 3", City("City 1"), listOf(Order(listOf(product1, product3), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memakai fungsi findMostExpensiveProductBy untuk mendapatkan produk paling mahal yang telah dipesan oleh customer
    val mostExpensiveProductByCustomer1 = findMostExpensiveProductBy(customer1)
    println("Most expensive product ordered by Customer 1: $mostExpensiveProductByCustomer1")

    // memakai fungsi getNumberOfTimesProductWasOrdered untuk menghitung berapa kali sebuah produk telah dipesan di seluruh toko
    val numberOfTimesProduct1WasOrdered = shop.getNumberOfTimesProductWasOrdered(product1)
    println("Number of times Product 1 was ordered in the shop: $numberOfTimesProduct1WasOrdered")
}