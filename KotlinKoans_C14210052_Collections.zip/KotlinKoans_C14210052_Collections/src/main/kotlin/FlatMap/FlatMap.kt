package FlatMap

// Return all products the given customer has ordered
fun Customer.getOrderedProducts(): List<Product> =
    // menggunakan flatMap untuk memetakan setiap pesanan pelanggan menjadi list produk yang dipesan
    orders.flatMap { it.products }

// Return all products that were ordered by at least one customer
fun Shop.getOrderedProducts(): Set<Product> =
    // memakai flatMap untuk memetakan setiap pelanggan ke daftar produk yang dipesan oleh pelanggan tersebut
    customers.flatMap(Customer::getOrderedProducts)
        // mengubah daftar produk-produk menjadi set untuk menghilangkan duplikasi produk
        .toSet()

fun main() {
    val product1 = Product("Product 1", 10.0)
    val product2 = Product("Product 2", 20.0)
    val product3 = Product("Product 3", 30.0)

    val customer1 = Customer("Customer 1", City("City 1"), listOf(Order(listOf(product1, product2), true)))
    val customer2 = Customer("Customer 2", City("City 2"), listOf(Order(listOf(product2, product3), true)))
    val customer3 = Customer("Customer 3", City("City 1"), listOf(Order(listOf(product1, product3), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memakai fungsi getOrderedProducts untuk mendapatkan semua produk yang dipesan oleh setidaknya satu pelanggan
    val orderedProducts = shop.getOrderedProducts()
    println("Ordered Products:")
    println(orderedProducts)

    // memakai fungsi getOrderedProducts untuk mendapatkan semua produk yang dipesan oleh pelanggan tertentu
    val customerOrderedProducts = customer1.getOrderedProducts()
    println("\nCustomer 1 Ordered Products:")
    println(customerOrderedProducts)
}
