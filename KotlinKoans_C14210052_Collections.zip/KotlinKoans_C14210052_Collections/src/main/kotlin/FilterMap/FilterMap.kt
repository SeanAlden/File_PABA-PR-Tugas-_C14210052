package FilterMap

fun Shop.getCustomerCities(): Set<City> {
    return customers.map { it.city }.toSet()
}

fun Shop.getCustomersFrom(city: City): List<Customer> {
    return customers.filter { it.city == city }
}

fun main() {
    val city1 = City("City 1")
    val city2 = City("City 2")

    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), true)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // menggunakan fungsi getCustomerCities untuk mendapatkan set kota pelanggan yang berbeda
    val customerCities = shop.getCustomerCities()
    println("Customer Cities:")
    println(customerCities)

    // menggunakan fungsi getCustomersFrom untuk mendapatkan list pelanggan dari kota tertentu
    val customerFromCity1 = shop.getCustomersFrom(city1)
    println("\nCustomers from city 1:")
    println(customerFromCity1)
}
