package Sum

// Return the sum of prices for all the products ordered by a given customer
fun moneySpentBy(customer: Customer): Double =
    // memakai flatMap untuk menggabungkan daftar produk dari setiap pesanan customer menjadi satu daftar produk
    customer.orders.flatMap { it.products }
        // memakai sumOf untuk menjumlahkan harga dari semua produk dalam daftar
        .sumOf { it.price }

fun main() {
    // membuat 3 objek product
    val product1 = Product("Product 1", 10.0)
    val product2 = Product("Product 2", 20.0)
    val product3 = Product("Product 3", 30.0)

    // membuat 3 objek customer dengan pesanan yang berbeda-beda
    val customer1 = Customer("Customer 1", City("City 1"), listOf(Order(listOf(product1, product2), true)))
    val customer2 = Customer("Customer 2", City("City 2"), listOf(Order(listOf(product2, product3), true)))
    val customer3 = Customer("Customer 3", City("City 1"), listOf(Order(listOf(product1, product3), false)))

    // membuat objek shop dengan list customer yang telah didefinisikan sebelumnya
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memakai fungsi moneySpentBy untuk menghitung total uang yang dihabiskan oleh customer tertentu
    val moneySpentByCustomer1 = moneySpentBy(customer1)
    println("Money spent by Customer 1: $moneySpentByCustomer1")

    // Menggunakan fungsi moneySpentBy untuk menghitung total uang yang dihabiskan oleh customer lainnya
    val moneySpentByCustomer2 = moneySpentBy(customer2)
    println("Money spent by Customer 2: $moneySpentByCustomer2")

    val moneySpentByCustomer3 = moneySpentBy(customer3)
    println("Money spent by Customer 3: $moneySpentByCustomer3")

}