package FoldAndReduce

// Return the set of products that were ordered by all customers
fun Shop.getProductsOrderedByAll(): Set<Product> =
    // mengambil daftar produk yang dipesan oleh setiap pelanggan menggunakan map
    customers.map(Customer::getOrderedProducts)
        // menggabungkan daftar produk menggunakan reduce untuk mendapatkan produk yang dipesan oleh semua pelanggan
        .reduce { orderedByAll, customer ->
            // menggunakan intersect untuk mendapatkan produk yang ada di kedua set produk
            orderedByAll.intersect(customer)
        }

// mengembalikan set produk yang dipesan oleh pelanggan tertentu
fun Customer.getOrderedProducts(): Set<Product> =
    // mengambil semua produk dari semua pesanan dan mengonversi ke set untuk menghindari duplikasi
    orders.flatMap(Order::products).toSet()

fun main() {
    // membuat objek product
    val product1 = Product("Product 1", 10.0)
    val product2 = Product("Product 2", 20.0)
    val product3 = Product("Product 3", 30.0)

    // membuat objek customer dengan pesanan yang berbeda
    val customer1 = Customer("Customer 1", City("City 1"), listOf(Order(listOf(product1, product2), true)))
    val customer2 = Customer("Customer 2", City("City 2"), listOf(Order(listOf(product2, product3), true)))
    val customer3 = Customer("Customer 3", City("City 1"), listOf(Order(listOf(product1, product3), false)))

    // membuat objek shop dengan list customer yang telah didefinisikan sebelumnya
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memakai fungsi getProductsOrderedByAll untuk mendapatkan set produk yang dipesan oleh semua pelanggan
    val productsOrderedByAll = shop.getProductsOrderedByAll()
    println("Products ordered by all customers:")
    println(productsOrderedByAll)
}

