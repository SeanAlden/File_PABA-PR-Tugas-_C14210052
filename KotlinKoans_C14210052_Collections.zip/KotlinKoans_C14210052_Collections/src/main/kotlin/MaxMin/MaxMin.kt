package MaxMin

// Return a customer who has placed the maximum amount of orders
fun Shop.getCustomerWithMaxOrders(): Customer? =
    // menggunakan maxByOrNull untuk mencari customer dengan jumlah pesanan maksimum
    customers.maxByOrNull { it.orders.size }

// Return the most expensive product that has been ordered by the given customer
fun getMostExpensiveProductBy(customer: Customer): Product? =
    // menggunakan flatMap untuk menggabungkan list produk dari semua pesanan pelanggan
    customer.orders
        . flatMap(Order::products)
        // menggunakan maxByOrNull untuk mencari produk paling mahal dalam daftar produk
        .maxByOrNull(Product::price)

fun main() {
    // membuat 3 objek produk yg disimpan pada variabel product1, product2, dan product3
    val product1 = Product("Product 1", 10.0)
    val product2 = Product("Product 2", 20.0)
    val product3 = Product("Product 3", 30.0)

    // membuat 3 objek customer dengan pesanan yang berbeda
    val customer1 = Customer("Customer 1", City("City 1"), listOf(Order(listOf(product1, product2), true)))
    val customer2 = Customer("Customer 2", City("City 2"), listOf(Order(listOf(product2, product3), true)))
    val customer3 = Customer("Customer 3", City("City 1"), listOf(Order(listOf(product1, product3), false)))

    // membuat objek shop dengan list pelanggan yang telah didefinisikan sebelumnya
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memakai fungsi getCustomerWithMaxOrders untuk mendapatkan pelanggan yang telah melakukan pesanan dengan jumlah maksimum
    val customerWithMaxOrders = shop.getCustomerWithMaxOrders()
    println("Customer with Max Orders:")
    println(customerWithMaxOrders)

    // memakai fungsi getMostExpensiveProductBy untuk mendapatkan produk paling mahal yang dipesan oleh pelanggan tertentu
    val mostExpensiveProductByCustomer1 = getMostExpensiveProductBy(customer1)
    println("\nMost Expensive Product ordered by Customer 1:")
    println(mostExpensiveProductByCustomer1)
}
