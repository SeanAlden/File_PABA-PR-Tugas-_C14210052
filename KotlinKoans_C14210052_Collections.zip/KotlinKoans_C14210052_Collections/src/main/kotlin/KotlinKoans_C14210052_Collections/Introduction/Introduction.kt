package KotlinKoans_C14210052_Collections.Introduction

fun Shop.getSetOfCustomers(): Set<Customer> {
    // menggunakan ekstensi properties customers untuk mengambil semua pelanggan dari shop dan mengubahnya menjadi Set
    return customers.toSet()
}

fun main() {
    // membuat 2 objek City yang disimpan dalam city1 dan city2
    val city1 = City("City 1")
    val city2 = City("City 2")

    // membuat 3 objek Customer dan disimpan dalam 3 variabel dibawah
    // masing-masing customer memiliki nilai parameter berbeda
    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), true)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    // membuat objek Shop dalam variabel shop dengan list dari customer 1, customer 2, dan customer 3
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // mengambil pelanggan-pelanggan dari shop tersebut, serta mengubahnya menjadi set
    val setOfCustomers = shop.getSetOfCustomers()
    println(setOfCustomers)
}