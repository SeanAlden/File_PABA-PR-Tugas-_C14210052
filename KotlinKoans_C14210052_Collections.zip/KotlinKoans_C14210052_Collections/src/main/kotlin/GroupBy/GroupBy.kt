package GroupBy

// Build a map that stores the customers living in a given city
fun Shop.groupCustomersByCity(): Map<City, List<Customer>> =
    // memakai fungsi groupBy untuk mengelompokkan customer berdasarkan kota mereka
    customers.groupBy { it.city }

fun main() {
    // membuat 2 objek City yang ditampung pada variabel city1 & city2
    val city1 = City("City 1")
    val city2 = City("City 2")

    // membuat 5 objek Customer yang disimpan pada 5 variabel dari customer1 sampai customer5
    // dengan kota-kota yang berbeda
    val customer1 = Customer("Customer 1", city1, emptyList())
    val customer2 = Customer("Customer 2", city2, emptyList())
    val customer3 = Customer("Customer 3", city1, emptyList())
    val customer4 = Customer("Customer 4", city2, emptyList())
    val customer5 = Customer("Customer 5", city1, emptyList())

    // membuat objek Shop dengan list pelanggan yang telah didefinisikan sebelumnya
    val shop = Shop("My Shop", listOf(customer1, customer2, customer3, customer4, customer5))

    // memakai fungsi groupCustomersByCity untuk mengelompokkan customer berdasarkan kota tempat tinggal mereka
    val groupedCustomersByCity = shop.groupCustomersByCity()
    println("Customers Grouped by City:")
    println(groupedCustomersByCity)
}