package Partition

fun Shop.getCustomersWithMoreUndeliveredOrders(): Set<Customer> {
    // memisah pesanan menjadi dua bagian, yaitu yang sudah dikirim dan yang belum dikirim
    val (undeliveredOrders, deliveredOrders) = customers.flatMap { it.orders }
        .partition { !it.isDelivered }

    // filterisasi pelanggan yang memiliki lebih banyak pesanan yang belum dikirim daripada yang sudah dikirim
    return customers.filter { customer ->
        val customerUndeliveredOrders = undeliveredOrders.count { it in customer.orders }
        val customerDeliveredOrders = deliveredOrders.count { it in customer.orders }
        // periksa apakah jumlah pesanan yang belum dikirim lebih banyak dari jumlah pesanan yang sudah dikirim
        customerUndeliveredOrders > customerDeliveredOrders
    }.toSet()
}

fun main() {
    val city1 = City("City 1")
    val city2 = City("City 2")

    // add pesanan yang sudah dikirim dan yang belum dikirim untuk pelanggan
    val customer1 = Customer("Customer 1", city1, listOf(Order(listOf(Product("Product 1", 10.0)), true)))
    val customer2 = Customer("Customer 2", city2, listOf(Order(listOf(Product("Product 2", 20.0)), false)))
    val customer3 = Customer("Customer 3", city1, listOf(Order(listOf(Product("Product 3", 30.0)), false)))

    val shop = Shop("My Shop", listOf(customer1, customer2, customer3))

    // memanggil fungsi getCustomersWithMoreUndeliveredOrders untuk mendapatkan pelanggan dengan lebih banyak pesanan yang belum dikirim
    val customersWithMoreUndeliveredOrders = shop.getCustomersWithMoreUndeliveredOrders()
    println("Customers with more undelivered orders:")
    println(customersWithMoreUndeliveredOrders)
}
