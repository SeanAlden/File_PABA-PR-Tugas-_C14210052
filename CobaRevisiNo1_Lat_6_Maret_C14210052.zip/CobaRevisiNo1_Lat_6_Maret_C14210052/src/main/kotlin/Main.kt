import java.util.Scanner

// Coba revisi no.1 Latihan 6 Maret 2024
// menggunakan inputan tambahan dengan meminta jumlah baris serta kolom
fun main(args: Array<String>) {
    val scanner = Scanner(System.`in`)

    print("Masukkan nilai N: ")
    val N = scanner.nextInt() // misal: N = 3

    print("Masukkan nilai M: ")
    val M = scanner.nextInt() // M = 2

    print("Masukkan elemen pertama (S): ")
    val S = scanner.next()[0] // S = A

    print("Masukkan jumlah baris dan kolom (RowColumn): ")
    val RowColumn = scanner.nextInt() // RowColumn = 5

    generatePattern(N, M, S, RowColumn)

    /*
    Output:
    A C * G I
    I A C * G
    G I A C *
    * G I A C
    C * G I A
     */
}

// fungsi untuk mengenerate pattern
fun generatePattern(N: Int, M: Int, S: Char, RowColumn: Int) {
    // membuat array 2d untuk char array sesuai pada baris & kolom yang ditentukan
    val pattern = Array(RowColumn) { CharArray(RowColumn) }

    // mengisi pola dengan karakter spasi
    for (i in 0 until RowColumn) {
        for (j in 0 until RowColumn) {
            pattern[i][j] = ' '
        }
    }

    // mengisi pola dengan karakter alfabet & bintang (*) sampai pada baris & kolom yang ditentukan
    var index = 0
    for (i in 0 until RowColumn) {
        for (j in 0 until RowColumn) {
            // mengisi elemen indeks pertama pada baris pertama dengan elemen inputan(S),
            // dan menghitung jarak antar alfabet berdasarkan inputan(M)
            var currentChar = (S + (index++ * M)).toChar()
            if (currentChar > 'Z') {
                currentChar = ('A'.toInt() + (currentChar.toInt() - 'Z'.toInt() - 1)).toChar()
            }
            pattern[i][j] = currentChar

            // mengisi elemen pada indeks ke-N dengan bintang
            if (index == N) {
                pattern[i][j] = '*'
            }

            index %= RowColumn
        }
        // membuat arah perpindahan elemen tiap indeks ke arah kanan
        index = (index - 1 + RowColumn) % RowColumn
    }

    // menampilkan pola sampai pada baris & kolom yang ditentukan
    for (i in 0 until RowColumn) {
        for (j in 0 until RowColumn) {
            print(pattern[i][j].toString() + " ")
        }
        println()
    }
}