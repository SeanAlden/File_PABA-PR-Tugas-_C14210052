package KotlinKoans_C14210052_Generics

import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.Collection

// extension function untuk Collection yang membagi elemen
// sesuai dengan predikat ke dalam dua koleksi yang diberikan.
fun <T, C : MutableCollection<T>> Collection<T>.partitionTo(
    first: C,
    second: C,
    predicate: (T) -> Boolean
): Pair<C, C> {
    for (element in this) {
        if (predicate(element)) {
            // menambahkan elemen ke dalam koleksi pertama jika predikat terpenuhi
            first.add(element)
        } else {
            // menambahkan elemen ke dalam koleksi kedua jika predikat tidak terpenuhi
            second.add(element)
        }
    }
    // mengembalikan pasangan koleksi yang telah dipartisi
    return Pair(first, second)
}

// function/method untuk membagi kata dan baris dari sebuah list
fun partitionWordsAndLines() {
    // memanggil fungsi partitionTo untuk membagi kata dan baris dari list yang diberikan
    val (words, lines) = listOf("a", "a b", "c", "d e")
        .partitionTo(ArrayList(), ArrayList()) { s -> !s.contains(" ") }
    // memeriksa hasil partisi
    check(words == listOf("a", "c"))
    check(lines == listOf("a b", "d e"))
}

// fungsi untuk membagi huruf dan simbol lain dari sebuah set
fun partitionLettersAndOtherSymbols() {
    // memanggil fungsi partitionTo untuk membagi huruf dan simbol lain dari set yang diberikan
    val (letters, other) = setOf('a', '%', 'r', '}')
        .partitionTo(HashSet(), HashSet()) { c -> c in 'a'..'z' || c in 'A'..'Z' }
    // memeriksa hasil partisi
    check(letters == setOf('a', 'r'))
    check(other == setOf('%', '}'))
}

fun main() {
    partitionWordsAndLines()
    partitionLettersAndOtherSymbols()
}